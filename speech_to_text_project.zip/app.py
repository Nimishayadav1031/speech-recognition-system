import speech_recognition as sr
import os

def transcribe_audio(file_path):
    recognizer = sr.Recognizer()
    with sr.AudioFile(file_path) as source:
        print("Listening to audio...")
        audio_data = recognizer.record(source)
        print("Transcribing...")
        try:
            text = recognizer.recognize_google(audio_data)
            return text
        except sr.UnknownValueError:
            return "Google Speech Recognition could not understand the audio."
        except sr.RequestError as e:
            return f"Could not request results; {e}"

if __name__ == "__main__":
    print("🔊 Basic Speech-to-Text System")
    print("Please ensure you have a WAV file (mono, 16kHz recommended).")
    audio_file = input("Enter the path to your audio file (e.g., sample.wav): ")
    if os.path.exists(audio_file):
        transcript = transcribe_audio(audio_file)
        print("\n📝 Transcription:")
        print(transcript)
    else:
        print("❌ File not found. Please check the path and try again.")