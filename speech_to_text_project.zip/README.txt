Speech-to-Text Transcription Tool (Offline)

Instructions:
1. Install requirements using:
   pip install -r requirements.txt

2. Prepare a short WAV file (e.g., sample.wav) - mono channel, 16kHz recommended.

3. Run the app:
   python app.py

4. Enter the path to the audio file when prompted.

Note:
- Works best with clear, short speech audio.
- Uses Google's free Web Speech API via the SpeechRecognition library.